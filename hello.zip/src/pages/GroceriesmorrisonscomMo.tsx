import { FunctionComponent } from "react";
import styles from "./GroceriesmorrisonscomMo.module.css";
const GroceriesmorrisonscomMo: FunctionComponent = () => {
  return (
    <div className={styles.groceriesmorrisonscomMo}>
      <div className={styles.main}>
        <div className={styles.section}>
          <div className={styles.divslickList}>
            <div className={styles.divsliderItem}>
              <img
                className={styles.sliderImage6jpgIcon}
                alt=""
                src="/sliderimage6jpg@2x.png"
              />
              <div className={styles.divcontentWrapper}>
                <div className={styles.divcontentHeader}>
                  <div className={styles.divcontentDescription}>
                    <div className={styles.exclusiveOffer}>Exclusive Offer</div>
                  </div>
                  <div className={styles.divcontentDiscount}>
                    <div className={styles.pseudo} />
                    <div className={styles.off}>-20% Off</div>
                  </div>
                </div>
                <div className={styles.divcontentMain}>
                  <div className={styles.heading3}>
                    <b className={styles.aDifferentKindContainer}>
                      <p className={styles.aDifferentKind}>
                        A different kind of
                      </p>
                      <p className={styles.aDifferentKind}>grocery store</p>
                    </b>
                  </div>
                  <div className={styles.onlyThisWeek}>
                    Only this week. Don’t miss...
                  </div>
                </div>
                <div className={styles.divcontentFooter}>
                  <div className={styles.from}>{`from `}</div>
                  <div className={styles.div}>$7.99</div>
                </div>
                <div className={styles.link}>
                  <div className={styles.shopNow}>Shop Now</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.buttonPrevious}>
            <div className={styles.icon}>
              <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            </div>
          </div>
          <div className={styles.buttonNext}>
            <div className={styles.icon}>
              <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
            </div>
          </div>
        </div>
        <div className={styles.section1}>
          <div className={styles.divcategories}>
            <div className={styles.divfirst}>
              <div className={styles.divcategory}>
                <img
                  className={styles.linkBaverages1jpg}
                  alt=""
                  src="/link--baverages1jpg@2x.png"
                />
                <div className={styles.divcategoryDetail}>
                  <div className={styles.biscuitsSnacksContainer}>
                    Beverages
                  </div>
                  <div className={styles.items}>11 Items</div>
                </div>
              </div>
            </div>
            <div className={styles.divcategoriesWrapper}>
              <div className={styles.divcategory1}>
                <div className={styles.divcategoryImage}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--biscuitssnacks1jpg@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail1}>
                  <div className={styles.heading3Link}>
                    <div className={styles.biscuitsSnacksContainer}>
                      <p className={styles.aDifferentKind}>{`Biscuits &`}</p>
                      <p className={styles.aDifferentKind}>Snacks</p>
                    </div>
                  </div>
                  <div className={styles.items}>6 Items</div>
                </div>
              </div>
              <div className={styles.divcategory2}>
                <div className={styles.divcategoryImage}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--breadbakery1jpg@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail2}>
                  <div
                    className={styles.biscuitsSnacksContainer}
                  >{`Breads & Bakery`}</div>
                  <div className={styles.items}>6 Items</div>
                </div>
              </div>
              <div className={styles.divcategory3}>
                <div className={styles.divcategoryImage}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--dairy1jpg@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail3}>
                  <div className={styles.heading3Link}>
                    <div className={styles.biscuitsSnacksContainer}>
                      <p className={styles.aDifferentKind}>{`Breakfast &`}</p>
                      <p className={styles.aDifferentKind}>Dairy</p>
                    </div>
                  </div>
                  <div className={styles.items}>8 Items</div>
                </div>
              </div>
              <div className={styles.divcategory4}>
                <div className={styles.divcategoryImage}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--categoryimage4png@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail2}>
                  <div className={styles.biscuitsSnacksContainer}>
                    Frozen Foods
                  </div>
                  <div className={styles.items}>7 Items</div>
                </div>
              </div>
              <div className={styles.divcategory5}>
                <div className={styles.divcategoryImage4}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--fruitvegetables1jpg@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail5}>
                  <div className={styles.heading3Link}>
                    <div className={styles.biscuitsSnacksContainer}>
                      <p className={styles.aDifferentKind}>{`Fruits &`}</p>
                      <p className={styles.aDifferentKind}>Vegetables</p>
                    </div>
                  </div>
                  <div className={styles.items}>12 Items</div>
                </div>
              </div>
              <div className={styles.divcategory6}>
                <div className={styles.divcategoryImage4}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--categoryimage2png@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail6}>
                  <div className={styles.heading3Link}>
                    <div className={styles.biscuitsSnacksContainer}>
                      <p className={styles.aDifferentKind}>{`Grocery &`}</p>
                      <p className={styles.aDifferentKind}>Staples</p>
                    </div>
                  </div>
                  <div className={styles.items}>7 Items</div>
                </div>
              </div>
              <div className={styles.divcategory7}>
                <div className={styles.divcategoryImage4}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--household1jpg@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail7}>
                  <div className={styles.heading3Link}>
                    <div className={styles.biscuitsSnacksContainer}>
                      <p className={styles.aDifferentKind}>Household</p>
                      <p className={styles.aDifferentKind}>Needs</p>
                    </div>
                  </div>
                  <div className={styles.items}>1 Items</div>
                </div>
              </div>
              <div className={styles.divcategory8}>
                <div className={styles.divcategoryImage4}>
                  <img
                    className={styles.linkBiscuitssnacks1jpg}
                    alt=""
                    src="/link--meat1jpg@2x.png"
                  />
                </div>
                <div className={styles.divcategoryDetail8}>
                  <div className={styles.heading3Link}>
                    <div className={styles.biscuitsSnacksContainer}>
                      <p className={styles.aDifferentKind}>{`Meats &`}</p>
                      <p className={styles.aDifferentKind}>Seafood</p>
                    </div>
                  </div>
                  <div className={styles.items}>5 Items</div>
                </div>
              </div>
              <div className={styles.pseudo1} />
            </div>
          </div>
        </div>
        <div className={styles.section2}>
          <div className={styles.divelementorWidgetWrap}>
            <div className={styles.divproducts}>
              <div className={styles.pseudo2} />
              <div className={styles.divproduct}>
                <div className={styles.divdealsHeader}>
                  <div className={styles.heading4}>
                    <div className={styles.dealsOfTheContainer}>
                      <span>{`Deals of the `}</span>
                      <b>week!</b>
                    </div>
                  </div>
                  <div className={styles.divdealsCounter}>
                    <div className={styles.divcountItem}>
                      <div className={styles.div1}>36</div>
                    </div>
                    <div className={styles.div2}>:</div>
                    <div className={styles.divcountItem1}>
                      <div className={styles.div1}>17</div>
                    </div>
                    <div className={styles.div4}>:</div>
                    <div className={styles.divcountItem2}>
                      <div className={styles.div1}>17</div>
                    </div>
                    <div className={styles.div6}>:</div>
                    <div className={styles.divcountItem3}>
                      <div className={styles.div1}>38</div>
                    </div>
                    <div className={styles.remainsUntilThe}>
                      Remains until the end of the offer
                    </div>
                  </div>
                </div>
                <div className={styles.divproductWrapper}>
                  <div className={styles.divthumbnailWrapper}>
                    <img
                      className={styles.linkProductImage50jpg}
                      alt=""
                      src="/link--productimage50jpg@2x.png"
                    />
                    <div className={styles.divdealDiscount}>
                      <div className={styles.div8}>19%</div>
                    </div>
                  </div>
                  <div className={styles.divcontentWrapper1}>
                    <div className={styles.spanprice}>
                      <div className={styles.del}>
                        <div className={styles.div9}>$5.49</div>
                      </div>
                      <div className={styles.ins}>
                        <div className={styles.div8}>$4.49</div>
                      </div>
                    </div>
                    <div className={styles.heading3Link6}>
                      <div className={styles.chobaniCompleteVanillaContainer}>
                        <p className={styles.aDifferentKind}>
                          Chobani Complete Vanilla Greek
                        </p>
                        <p className={styles.aDifferentKind}>Yogurt</p>
                      </div>
                    </div>
                    <div className={styles.divproductMeta}>
                      <div className={styles.divproductUnit}>
                        <div className={styles.kg}>1 kg</div>
                      </div>
                      <div className={styles.divproductAvailable}>
                        <div className={styles.inStock}>In Stock</div>
                      </div>
                    </div>
                    <div className={styles.divproductRating}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector2.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector3.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector4.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector5.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector6.svg"
                          />
                        </div>
                        <div className={styles.span}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector7.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector8.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector9.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector10.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector11.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.divproductCount}>
                      <div className={styles.divproductPcs}>
                        <div className={styles.available}>{`Available : `}</div>
                        <div className={styles.div12}>63</div>
                      </div>
                      <div className={styles.divproductProgress}>
                        <div className={styles.spanprogress} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divelementorWidgetWrap1}>
            <div className={styles.divproducts1}>
              <div className={styles.pseudo3} />
              <div className={styles.divproduct1}>
                <div className={styles.heading3Link}>
                  <div className={styles.divthumbnailWrapper}>
                    <img
                      className={styles.linkProductImage62346x31}
                      alt=""
                      src="/link--productimage62346x310jpg@2x.png"
                    />
                    <div className={styles.divproductBadges}>
                      <div className={styles.spanbadge}>
                        <div className={styles.organic}>23%</div>
                      </div>
                      <div className={styles.spanbadge1}>
                        <b className={styles.recommended}>recommended</b>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcontentWrapper2}>
                    <div className={styles.heading3Link7}>
                      <div className={styles.allNaturalItalianStyleContainer}>
                        <p className={styles.aDifferentKind}>
                          All Natural Italian-Style
                        </p>
                        <p className={styles.aDifferentKind}>
                          Chicken Meatballs
                        </p>
                      </div>
                    </div>
                    <div className={styles.inStock1}>In Stock</div>
                    <div className={styles.divproductRating1}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector12.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector13.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector14.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector15.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector16.svg"
                          />
                        </div>
                        <div className={styles.span1}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector17.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector18.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector19.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector20.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector21.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.spanprice1}>
                      <div className={styles.del1}>
                        <div className={styles.div15}>$9.35</div>
                      </div>
                      <div className={styles.ins1}>
                        <div className={styles.div16}>$7.25</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.divproduct2}>
                <div className={styles.heading3Link}>
                  <div className={styles.divthumbnailWrapper2}>
                    <img
                      className={styles.linkProductImage60346x31}
                      alt=""
                      src="/link--productimage60346x310jpg@2x.png"
                    />
                    <div className={styles.spanbadge2}>
                      <div className={styles.organic}>24%</div>
                    </div>
                  </div>
                  <div className={styles.divcontentWrapper2}>
                    <div className={styles.heading3Link8}>
                      <div className={styles.allNaturalItalianStyleContainer}>
                        <p className={styles.aDifferentKind}>
                          Angie’s Boomchickapop Sweet
                        </p>
                        <p
                          className={styles.aDifferentKind}
                        >{`& Salty Kettle Corn`}</p>
                      </div>
                    </div>
                    <div className={styles.inStock1}>In Stock</div>
                    <div className={styles.divproductRating1}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector12.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector13.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector14.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector15.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector16.svg"
                          />
                        </div>
                        <div className={styles.span1}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector17.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector18.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector19.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector20.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector21.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.spanprice1}>
                      <div className={styles.del1}>
                        <div className={styles.div15}>$4.29</div>
                      </div>
                      <div className={styles.ins2}>
                        <div className={styles.div16}>$3.29</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.divproduct3}>
                <div className={styles.heading3Link}>
                  <div className={styles.divthumbnailWrapper}>
                    <img
                      className={styles.linkProductImage62346x31}
                      alt=""
                      src="/link--productimage46346x310jpg@2x.png"
                    />
                    <div className={styles.divproductBadges}>
                      <div className={styles.spanbadge3}>
                        <div className={styles.organic}>19%</div>
                      </div>
                      <div className={styles.spanbadge4}>
                        <div className={styles.organic}>organic</div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcontentWrapper2}>
                    <div className={styles.heading3Link9}>
                      <div className={styles.allNaturalItalianStyleContainer}>
                        <p className={styles.aDifferentKind}>
                          Field Roast Chao Cheese
                        </p>
                        <p className={styles.aDifferentKind}>Creamy Original</p>
                      </div>
                    </div>
                    <div className={styles.inStock1}>In Stock</div>
                    <div className={styles.divproductRating1}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector12.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector13.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector14.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector15.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector16.svg"
                          />
                        </div>
                        <div className={styles.span}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector17.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector18.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector19.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector20.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector21.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.spanprice1}>
                      <div className={styles.del1}>
                        <div className={styles.div15}>$24.00</div>
                      </div>
                      <div className={styles.ins3}>
                        <div className={styles.div16}>$19.50</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.divproduct4}>
                <div className={styles.heading3Link}>
                  <div className={styles.divthumbnailWrapper4}>
                    <img
                      className={styles.linkProductImage45346x31}
                      alt=""
                      src="/link--productimage45346x310jpg@2x.png"
                    />
                  </div>
                  <div className={styles.divcontentWrapper5}>
                    <div className={styles.heading3Link10}>
                      <div className={styles.allNaturalItalianStyleContainer}>
                        <p className={styles.aDifferentKind}>
                          Foster Farms Takeout Crispy
                        </p>
                        <p className={styles.aDifferentKind}>
                          Classic Buffalo Wings
                        </p>
                      </div>
                    </div>
                    <div className={styles.inStock1}>In Stock</div>
                    <div className={styles.divproductRating1}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector22.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector23.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector24.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector25.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector26.svg"
                          />
                        </div>
                        <div className={styles.span1}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector27.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector28.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector29.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector30.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector31.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.spanprice4}>
                      <div className={styles.div16}>
                        <span>$7.25</span>
                        <span className={styles.span5}>{` – `}</span>
                        <span className={styles.span6}>$49.99</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.divproduct5}>
                <div className={styles.heading3Link}>
                  <div className={styles.divthumbnailWrapper}>
                    <img
                      className={styles.linkProductImage62346x31}
                      alt=""
                      src="/link--productimage59346x310jpg@2x.png"
                    />
                    <div className={styles.divproductBadges}>
                      <div className={styles.spanbadge5}>
                        <div className={styles.organic}>10%</div>
                      </div>
                      <div className={styles.spanbadge4}>
                        <div className={styles.organic}>organic</div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcontentWrapper2}>
                    <div className={styles.heading3Link11}>
                      <div className={styles.allNaturalItalianStyleContainer}>
                        <p className={styles.aDifferentKind}>
                          Blue Diamond Almonds Lightly
                        </p>
                        <p className={styles.aDifferentKind}>Salted</p>
                      </div>
                    </div>
                    <div className={styles.inStock1}>In Stock</div>
                    <div className={styles.divproductRating1}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector22.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector23.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector24.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector25.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector26.svg"
                          />
                        </div>
                        <div className={styles.span}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector27.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector28.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector29.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector30.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector31.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.spanprice5}>
                      <div className={styles.del1}>
                        <div className={styles.div15}>$11.68</div>
                      </div>
                      <div className={styles.ins4}>
                        <div className={styles.div16}>$10.58</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.divproduct6}>
                <div className={styles.heading3Link}>
                  <div className={styles.divthumbnailWrapper2}>
                    <img
                      className={styles.linkProductImage60346x31}
                      alt=""
                      src="/link--productimage58346x310jpg@2x.png"
                    />
                    <div className={styles.spanbadge7}>
                      <div className={styles.organic}>12%</div>
                    </div>
                  </div>
                  <div className={styles.divcontentWrapper7}>
                    <div className={styles.heading3Link12}>
                      <div className={styles.allNaturalItalianStyleContainer}>
                        Blueberries – 1 Pint Package
                      </div>
                    </div>
                    <div className={styles.inStock6}>In Stock</div>
                    <div className={styles.divproductRating6}>
                      <div className={styles.imgRated500OutOf5}>
                        <div className={styles.icon2}>
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector32.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector33.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector34.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector35.svg"
                          />
                          <img
                            className={styles.vectorIcon2}
                            alt=""
                            src="/vector36.svg"
                          />
                        </div>
                        <div className={styles.span8}>
                          <div className={styles.icon3}>
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector37.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector38.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector39.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector40.svg"
                            />
                            <img
                              className={styles.vectorIcon2}
                              alt=""
                              src="/vector41.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcountRating}>
                        <div className={styles.div11}>1</div>
                      </div>
                    </div>
                    <div className={styles.spanprice6}>
                      <div className={styles.del1}>
                        <div className={styles.div15}>$4.49</div>
                      </div>
                      <div className={styles.ins5}>
                        <div className={styles.div16}>$3.99</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.section3}>
          <div className={styles.divelementorWidgetWrap2}>
            <div className={styles.divbannerWrapper}>
              <img
                className={styles.bacolaBanner11jpgIcon}
                alt=""
                src="/bacolabanner11jpg@2x.png"
              />
              <div className={styles.divbannerContent}>
                <div className={styles.weekendDiscount40}>
                  Weekend Discount 40%
                </div>
                <div className={styles.divcontentMain1}>
                  <div className={styles.heading34}>Cookie and Ice Cream</div>
                  <div className={styles.bacolaWeekendDiscount}>
                    Bacola Weekend Discount
                  </div>
                </div>
                <div className={styles.link1}>
                  <div className={styles.addToCart}>Shop Now</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divelementorWidgetWrap3}>
            <div className={styles.divbannerWrapper}>
              <img
                className={styles.bacolaBanner11jpgIcon}
                alt=""
                src="/bacolabanner12jpg@2x.png"
              />
              <div className={styles.divbannerContent}>
                <div className={styles.weekendDiscount40}>
                  Weekend Discount 30%
                </div>
                <div className={styles.divcontentMain1}>
                  <div className={styles.heading34}>Cookie and Ice Cream</div>
                  <div className={styles.bacolaWeekendDiscount}>
                    Bacola Weekend Discount
                  </div>
                </div>
                <div className={styles.link2}>
                  <div className={styles.addToCart}>Shop Now</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.section4}>
          <div className={styles.divmoduleHeader}>
            <div className={styles.divcolumn}>
              <div className={styles.heading3Link}>
                <div className={styles.bestSellers}>Best Sellers</div>
              </div>
              <div className={styles.diventryDescription}>
                <div className={styles.doNotMiss}>
                  Do not miss the current offers until the end of March.
                </div>
              </div>
            </div>
            <div className={styles.divcolumn1}>
              <div className={styles.link3}>
                <div className={styles.viewAll}>View All</div>
                <div className={styles.iklbthIconRightArrow}>
                  <div className={styles.icon16}>
                    <img
                      className={styles.vectorIcon72}
                      alt=""
                      src="/vector42.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divmoduleBody}>
            <div className={styles.pseudo4} />
            <div className={styles.divproducts2}>
              <div className={styles.divslickList1}>
                <div className={styles.divslickTrack}>
                  <div className={styles.divproduct7}>
                    <div className={styles.divproductWrapper7}>
                      <div className={styles.divthumbnailWrapper7}>
                        <img
                          className={styles.linkProductImage62346x311}
                          alt=""
                          src="/link--productimage62346x310jpg1@2x.png"
                        />
                        <div className={styles.divproductBadges3}>
                          <div className={styles.spanbadge}>
                            <div className={styles.organic}>23%</div>
                          </div>
                          <div className={styles.spanbadge1}>
                            <b className={styles.recommended}>recommended</b>
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcontentWrapper8}>
                        <div className={styles.heading3Link13}>
                          <div className={styles.freshOrganicBroccoliContainer}>
                            <p className={styles.aDifferentKind}>
                              All Natural Italian-Style
                            </p>
                            <p className={styles.aDifferentKind}>
                              Chicken Meatballs
                            </p>
                          </div>
                        </div>
                        <div className={styles.inStock1}>In Stock</div>
                        <div className={styles.divproductRating7}>
                          <div className={styles.imgRated500OutOf5}>
                            <div className={styles.icon2}>
                              <img
                                className={styles.vectorIcon2}
                                alt=""
                                src="/vector43.svg"
                              />
                              <img
                                className={styles.vectorIcon2}
                                alt=""
                                src="/vector44.svg"
                              />
                              <img
                                className={styles.vectorIcon2}
                                alt=""
                                src="/vector45.svg"
                              />
                              <img
                                className={styles.vectorIcon2}
                                alt=""
                                src="/vector46.svg"
                              />
                              <img
                                className={styles.vectorIcon2}
                                alt=""
                                src="/vector47.svg"
                              />
                            </div>
                            <div className={styles.span}>
                              <div className={styles.icon3}>
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector48.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector49.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector50.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector51.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector52.svg"
                                />
                              </div>
                            </div>
                          </div>
                          <div className={styles.divcountRating}>
                            <div className={styles.div11}>1</div>
                          </div>
                        </div>
                        <div className={styles.spanprice5}>
                          <div className={styles.del1}>
                            <div className={styles.div15}>$9.35</div>
                          </div>
                          <div className={styles.ins6}>
                            <div className={styles.div16}>$7.25</div>
                          </div>
                        </div>
                        <div className={styles.linkAddAllNaturalItalia}>
                          <div className={styles.addToCart}>Add to cart</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divproduct7}>
                    <div className={styles.divproductWrapper7}>
                      <div className={styles.divthumbnailWrapper8}>
                        <img
                          className={styles.linkProductImage60346x311}
                          alt=""
                          src="/link--productimage60346x310jpg1@2x.png"
                        />
                        <div className={styles.spanbadge2}>
                          <div className={styles.organic}>24%</div>
                        </div>
                      </div>
                      <div className={styles.divcontentWrapper8}>
                        <div className={styles.heading3Link14}>
                          <div className={styles.freshOrganicBroccoliContainer}>
                            <p className={styles.aDifferentKind}>
                              Angie’s Boomchickapop
                            </p>
                            <p
                              className={styles.aDifferentKind}
                            >{`Sweet & Salty Kettle Corn`}</p>
                          </div>
                        </div>
                        <div className={styles.inStock1}>In Stock</div>
                        <div className={styles.divproductRating8}>
                          <div className={styles.divproductRating9}>
                            <div className={styles.imgRated500OutOf5}>
                              <div className={styles.icon2}>
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector43.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector44.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector45.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector46.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector53.svg"
                                />
                              </div>
                              <div className={styles.span}>
                                <div className={styles.icon3}>
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector48.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector49.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector50.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector51.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector54.svg"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className={styles.divcountRating}>
                              <div className={styles.div11}>1</div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.spanprice5}>
                          <div className={styles.del1}>
                            <div className={styles.div15}>$4.29</div>
                          </div>
                          <div className={styles.ins7}>
                            <div className={styles.div16}>$3.29</div>
                          </div>
                        </div>
                        <div className={styles.linkAddAllNaturalItalia}>
                          <div className={styles.addToCart}>Add to cart</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divproduct7}>
                    <div className={styles.divproductWrapper7}>
                      <div className={styles.divthumbnailWrapper7}>
                        <img
                          className={styles.linkProductImage62346x311}
                          alt=""
                          src="/link--productimage46346x310jpg1@2x.png"
                        />
                        <div className={styles.divproductBadges4}>
                          <div className={styles.spanbadge3}>
                            <div className={styles.organic}>19%</div>
                          </div>
                          <div className={styles.spanbadge4}>
                            <div className={styles.organic}>organic</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcontentWrapper8}>
                        <div className={styles.heading3Link15}>
                          <div className={styles.freshOrganicBroccoliContainer}>
                            <p className={styles.aDifferentKind}>
                              Field Roast Chao Cheese
                            </p>
                            <p className={styles.aDifferentKind}>
                              Creamy Original
                            </p>
                          </div>
                        </div>
                        <div className={styles.inStock1}>In Stock</div>
                        <div className={styles.divproductRating8}>
                          <div className={styles.divproductRating9}>
                            <div className={styles.imgRated500OutOf5}>
                              <div className={styles.icon2}>
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector43.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector44.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector45.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector46.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector53.svg"
                                />
                              </div>
                              <div className={styles.span}>
                                <div className={styles.icon3}>
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector48.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector49.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector50.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector51.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector54.svg"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className={styles.divcountRating}>
                              <div className={styles.div11}>1</div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.spanprice5}>
                          <div className={styles.del1}>
                            <div className={styles.div15}>$24.00</div>
                          </div>
                          <div className={styles.ins8}>
                            <div className={styles.div16}>$19.50</div>
                          </div>
                        </div>
                        <div className={styles.linkAddAllNaturalItalia}>
                          <div className={styles.addToCart}>Add to cart</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divproduct7}>
                    <div className={styles.divproductWrapper7}>
                      <div className={styles.divthumbnailWrapper7}>
                        <img
                          className={styles.linkProductImage62346x311}
                          alt=""
                          src="/link--productimage59346x310jpg1@2x.png"
                        />
                        <div className={styles.divproductBadges4}>
                          <div className={styles.spanbadge5}>
                            <div className={styles.organic}>10%</div>
                          </div>
                          <div className={styles.spanbadge4}>
                            <div className={styles.organic}>organic</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcontentWrapper8}>
                        <div className={styles.heading3Link16}>
                          <div className={styles.freshOrganicBroccoliContainer}>
                            <p className={styles.aDifferentKind}>
                              Blue Diamond Almonds
                            </p>
                            <p className={styles.aDifferentKind}>
                              Lightly Salted
                            </p>
                          </div>
                        </div>
                        <div className={styles.inStock1}>In Stock</div>
                        <div className={styles.divproductRating8}>
                          <div className={styles.divproductRating9}>
                            <div className={styles.imgRated500OutOf5}>
                              <div className={styles.icon2}>
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector43.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector44.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector45.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector46.svg"
                                />
                                <img
                                  className={styles.vectorIcon2}
                                  alt=""
                                  src="/vector53.svg"
                                />
                              </div>
                              <div className={styles.span}>
                                <div className={styles.icon3}>
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector48.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector49.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector50.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector51.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector54.svg"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className={styles.divcountRating}>
                              <div className={styles.div11}>1</div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.spanprice5}>
                          <div className={styles.del1}>
                            <div className={styles.div15}>$11.68</div>
                          </div>
                          <div className={styles.ins9}>
                            <div className={styles.div16}>$10.58</div>
                          </div>
                        </div>
                        <div className={styles.linkAddAllNaturalItalia}>
                          <div className={styles.addToCart}>Add to cart</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.divproduct7}>
                    <div className={styles.divproductWrapper7}>
                      <div className={styles.divthumbnailWrapper7}>
                        <img
                          className={styles.linkProductImage62346x311}
                          alt=""
                          src="/link--productimage57346x310jpg@2x.png"
                        />
                        <div className={styles.divproductBadges4}>
                          <div className={styles.spanbadge15}>
                            <div className={styles.organic}>29%</div>
                          </div>
                          <div className={styles.spanbadge4}>
                            <div className={styles.organic}>organic</div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.divcontentWrapper12}>
                        <div className={styles.heading3Link17}>
                          <div className={styles.freshOrganicBroccoliContainer}>
                            <p className={styles.aDifferentKind}>
                              Fresh Organic Broccoli
                            </p>
                            <p className={styles.aDifferentKind}>Crowns</p>
                          </div>
                        </div>
                        <div className={styles.divproductMeta1}>
                          <div className={styles.divproductUnit}>
                            <div className={styles.kg}>1 kg</div>
                          </div>
                          <div className={styles.divproductAvailable}>
                            <div className={styles.inStock}>In Stock</div>
                          </div>
                        </div>
                        <div className={styles.divproductRating14}>
                          <div className={styles.divcountRating}>
                            <div className={styles.divproductRating15}>
                              <div className={styles.imgRated500OutOf5}>
                                <div className={styles.icon2}>
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector43.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector44.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector45.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector46.svg"
                                  />
                                  <img
                                    className={styles.vectorIcon2}
                                    alt=""
                                    src="/vector53.svg"
                                  />
                                </div>
                                <div className={styles.span}>
                                  <div className={styles.icon3}>
                                    <img
                                      className={styles.vectorIcon2}
                                      alt=""
                                      src="/vector48.svg"
                                    />
                                    <img
                                      className={styles.vectorIcon2}
                                      alt=""
                                      src="/vector49.svg"
                                    />
                                    <img
                                      className={styles.vectorIcon2}
                                      alt=""
                                      src="/vector50.svg"
                                    />
                                    <img
                                      className={styles.vectorIcon2}
                                      alt=""
                                      src="/vector51.svg"
                                    />
                                    <img
                                      className={styles.vectorIcon2}
                                      alt=""
                                      src="/vector54.svg"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className={styles.divcountRating}>
                                <div className={styles.div11}>1</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className={styles.spanprice11}>
                          <div className={styles.del1}>
                            <div className={styles.div15}>$6.77</div>
                          </div>
                          <div className={styles.ins10}>
                            <div className={styles.div16}>$4.85</div>
                          </div>
                        </div>
                        <div className={styles.linkAddFreshOrganicBroc}>
                          <div className={styles.addToCart}>Add to cart</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.buttonPrevious1}>
                <div className={styles.icon}>
                  <img
                    className={styles.vectorIcon}
                    alt=""
                    src="/vector55.svg"
                  />
                </div>
              </div>
              <div className={styles.buttonNext1}>
                <div className={styles.icon}>
                  <img
                    className={styles.vectorIcon}
                    alt=""
                    src="/vector56.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.sectionLink}>
          <b className={styles.saveAnExtra}>
            Save an Extra 5-10 % On Every Autoship Order!
          </b>
        </div>
        <div className={styles.section5}>
          <div className={styles.pseudo3} />
          <div className={styles.divproduct12}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage346x310jpg@2x.png"
                />
                <div className={styles.spanbadge2}>
                  <div className={styles.organic}>26%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link18}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      Zevia Kidz Strawberry
                    </p>
                    <p className={styles.aDifferentKind}>
                      Lemonade Zero Calorie…
                    </p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector57.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector58.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector59.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector60.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector61.svg"
                      />
                    </div>
                    <div className={styles.span}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector62.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector63.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector64.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector65.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector66.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$7.95</div>
                  </div>
                  <div className={styles.ins11}>
                    <div className={styles.div16}>$5.95</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct13}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage2346x310jpg@2x.png"
                />
                <div className={styles.spanbadge2}>
                  <div className={styles.organic}>40%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link19}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      Wheat Thins Original
                    </p>
                    <p className={styles.aDifferentKind}>Crackers</p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector57.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector58.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector59.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector60.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector67.svg"
                      />
                    </div>
                    <div className={styles.span}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector62.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector63.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector64.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector65.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector68.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$5.00</div>
                  </div>
                  <div className={styles.ins12}>
                    <div className={styles.div16}>$3.00</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct14}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage3346x310jpg@2x.png"
                />
                <div className={styles.spanbadge2}>
                  <div className={styles.organic}>26%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link20}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      Werther’s Original Caramel
                    </p>
                    <p className={styles.aDifferentKind}>Hard Candies</p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector57.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector58.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector59.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector60.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector67.svg"
                      />
                    </div>
                    <div className={styles.span}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector62.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector63.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector64.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector65.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector68.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$20.00</div>
                  </div>
                  <div className={styles.ins13}>
                    <div className={styles.div16}>$14.97</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct15}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage4346x310jpg@2x.png"
                />
                <div className={styles.spanbadge2}>
                  <div className={styles.organic}>26%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper16}>
                <div className={styles.heading3Link21}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    Warrior Blend Organic
                  </div>
                </div>
                <div className={styles.inStock15}>In Stock</div>
                <div className={styles.divproductRating19}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector69.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector70.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector71.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector72.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector73.svg"
                      />
                    </div>
                    <div className={styles.span8}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector74.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector75.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector76.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector77.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector78.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice15}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$39.00</div>
                  </div>
                  <div className={styles.ins14}>
                    <div className={styles.div16}>$29.00</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct16}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage5346x310jpg@2x.png"
                />
                <div className={styles.spanbadge21}>
                  <div className={styles.organic}>14%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link22}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      Vital Farms Pasture-Raised
                    </p>
                    <p
                      className={styles.aDifferentKind}
                    >{`Egg Bites Bacon & Cheddar`}</p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector57.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector58.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector59.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector60.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector67.svg"
                      />
                    </div>
                    <div className={styles.span1}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector62.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector63.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector64.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector65.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector68.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$29.00</div>
                  </div>
                  <div className={styles.ins15}>
                    <div className={styles.div16}>$25.00</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct17}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage7346x310jpg@2x.png"
                />
                <div className={styles.spanbadge2}>
                  <div className={styles.organic}>38%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link14}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      USDA Choice Angus Beef
                    </p>
                    <p className={styles.aDifferentKind}>Stew Meat</p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector79.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector80.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector81.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector82.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector83.svg"
                      />
                    </div>
                    <div className={styles.span1}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector84.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector85.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector86.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector87.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector88.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$79.99</div>
                  </div>
                  <div className={styles.ins16}>
                    <div className={styles.div16}>$49.99</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct18}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage9346x310jpg@2x.png"
                />
                <div className={styles.spanbadge2}>
                  <div className={styles.organic}>31%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link24}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      Tropicana Pineapple Mango
                    </p>
                    <p className={styles.aDifferentKind}>Drink</p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector79.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector80.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector81.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector82.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector89.svg"
                      />
                    </div>
                    <div className={styles.span1}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector84.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector85.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector86.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector87.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector90.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$3.29</div>
                  </div>
                  <div className={styles.ins17}>
                    <div className={styles.div16}>$2.29</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct19}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage11346x310jpg@2x.png"
                />
                <div className={styles.spanbadge24}>
                  <div className={styles.organic}>15%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper20}>
                <div className={styles.heading3Link25}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    Organic Sweet Lime
                  </div>
                </div>
                <div className={styles.divproductMeta2}>
                  <div className={styles.divproductUnit}>
                    <div className={styles.kg}>1 kg</div>
                  </div>
                  <div className={styles.divproductAvailable}>
                    <div className={styles.inStock}>In Stock</div>
                  </div>
                </div>
                <div className={styles.divproductRating23}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector91.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector92.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector93.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector94.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector95.svg"
                      />
                    </div>
                    <div className={styles.span1}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector96.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector97.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector98.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector99.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector100.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice19}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$6.99</div>
                  </div>
                  <div className={styles.ins18}>
                    <div className={styles.div16}>$5.99</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct20}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage12346x310jpg@2x.png"
                />
                <div className={styles.spanbadge25}>
                  <div className={styles.organic}>25%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper20}>
                <div className={styles.heading3Link26}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    Fresh Organic Strawberry
                  </div>
                </div>
                <div className={styles.divproductMeta2}>
                  <div className={styles.divproductUnit}>
                    <div className={styles.kg}>0.5 kg</div>
                  </div>
                  <div className={styles.divproductAvailable3}>
                    <div className={styles.inStock}>In Stock</div>
                  </div>
                </div>
                <div className={styles.divproductRating23}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector91.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector92.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector93.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector94.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector95.svg"
                      />
                    </div>
                    <div className={styles.span}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector96.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector97.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector98.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector99.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector100.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice19}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$12.00</div>
                  </div>
                  <div className={styles.ins19}>
                    <div className={styles.div16}>$9.00</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divproduct21}>
            <div className={styles.heading3Link}>
              <div className={styles.divthumbnailWrapper12}>
                <img
                  className={styles.linkProductImage346x310j}
                  alt=""
                  src="/link--productimage14346x310jpg@2x.png"
                />
                <div className={styles.spanbadge7}>
                  <div className={styles.organic}>21%</div>
                </div>
              </div>
              <div className={styles.divcontentWrapper13}>
                <div className={styles.heading3Link27}>
                  <div className={styles.allNaturalItalianStyleContainer}>
                    <p className={styles.aDifferentKind}>
                      Sol-ti Coconut Charcoal
                    </p>
                    <p className={styles.aDifferentKind}>SuperAde</p>
                  </div>
                </div>
                <div className={styles.inStock12}>In Stock</div>
                <div className={styles.divproductRating16}>
                  <div className={styles.imgRated500OutOf5}>
                    <div className={styles.icon2}>
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector79.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector80.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector81.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector82.svg"
                      />
                      <img
                        className={styles.vectorIcon2}
                        alt=""
                        src="/vector89.svg"
                      />
                    </div>
                    <div className={styles.span1}>
                      <div className={styles.icon3}>
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector84.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector85.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector86.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector87.svg"
                        />
                        <img
                          className={styles.vectorIcon2}
                          alt=""
                          src="/vector90.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className={styles.divcountRating}>
                    <div className={styles.div11}>1</div>
                  </div>
                </div>
                <div className={styles.spanprice1}>
                  <div className={styles.del1}>
                    <div className={styles.div15}>$4.97</div>
                  </div>
                  <div className={styles.ins20}>
                    <div className={styles.div16}>$3.97</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.section6}>
          <div className={styles.divelementorWidgetWrap4}>
            <div className={styles.divbannerWrapper2}>
              <img
                className={styles.bacolaBanner05jpgIcon}
                alt=""
                src="/bacolabanner05jpg@2x.png"
              />
              <div className={styles.divbannerContent2}>
                <div className={styles.weekendDiscount40}>
                  Weekend Discount 20%
                </div>
                <div className={styles.divcontentMain3}>
                  <div className={styles.heading34}>Natural Eggs</div>
                  <div className={styles.eatOneEvery}>Eat one every day</div>
                </div>
                <div className={styles.link4}>
                  <div className={styles.addToCart}>Shop Now</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divelementorWidgetWrap4}>
            <div className={styles.divbannerWrapper2}>
              <img
                className={styles.bacolaBanner05jpgIcon}
                alt=""
                src="/bacolabanner06jpg@2x.png"
              />
              <div className={styles.divbannerContent3}>
                <div className={styles.weekendDiscount40}>
                  Weekend Discount 40%
                </div>
                <div className={styles.divcontentMain4}>
                  <div className={styles.heading34}>Taste the Best</div>
                  <div className={styles.eatOneEvery}>Shine the morning</div>
                </div>
                <div className={styles.link4}>
                  <div className={styles.addToCart}>Shop Now</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divelementorWidgetWrap4}>
            <div className={styles.divbannerWrapper2}>
              <img
                className={styles.bacolaBanner05jpgIcon}
                alt=""
                src="/bacolabanner10jpg@2x.png"
              />
              <div className={styles.divbannerContent4}>
                <div className={styles.weekendDiscount40}>
                  Weekend Discount 30%
                </div>
                <div className={styles.divcontentMain5}>
                  <div className={styles.heading34}>Ditch the Junk</div>
                  <div className={styles.eatOneEvery}>
                    Breakfast made better
                  </div>
                </div>
                <div className={styles.link4}>
                  <div className={styles.addToCart}>Shop Now</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.section7}>
          <div className={styles.divcol12}>
            <div className={styles.article}>
              <div className={styles.figureLink}>
                <img
                  className={styles.blog3370x260jpgIcon}
                  alt=""
                  src="/blog3370x260jpg@2x.png"
                />
              </div>
              <div className={styles.divpostWrapper}>
                <div className={styles.linkTips}>{`Tips & Tricks`}</div>
                <div className={styles.heading2Link}>
                  <div className={styles.butIMustContainer}>
                    <p className={styles.aDifferentKind}>
                      But I must explain to you how all this
                    </p>
                    <p className={styles.aDifferentKind}>mistaken idea</p>
                  </div>
                </div>
                <div className={styles.diventryMeta}>
                  <div className={styles.spanmetaItemmargin}>
                    <div className={styles.shopNow}>3 May 2021</div>
                  </div>
                  <div className={styles.spanmetaItemmargin1}>
                    <div className={styles.shopNow}>3 comments</div>
                  </div>
                  <div className={styles.spanmetaItemmargin2}>
                    <div className={styles.spanmetaItem}>
                      <i className={styles.by}>{`by `}</i>
                      <div className={styles.linkBacola}>Bacola</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divcol12}>
            <div className={styles.article}>
              <div className={styles.figureLink}>
                <img
                  className={styles.blog3370x260jpgIcon}
                  alt=""
                  src="/blog5370x260jpg@2x.png"
                />
              </div>
              <div className={styles.divpostWrapper}>
                <div className={styles.linkTips}>Grocery</div>
                <div className={styles.heading2Link}>
                  <div className={styles.butIMustContainer}>
                    <p className={styles.aDifferentKind}>
                      The Problem With Typefaces on the
                    </p>
                    <p className={styles.aDifferentKind}>Web</p>
                  </div>
                </div>
                <div className={styles.diventryMeta}>
                  <div className={styles.spanmetaItemmargin}>
                    <div className={styles.shopNow}>3 May 2021</div>
                  </div>
                  <div className={styles.spanmetaItemmargin1}>
                    <div className={styles.shopNow}>3 comments</div>
                  </div>
                  <div className={styles.spanmetaItemmargin2}>
                    <div className={styles.spanmetaItem}>
                      <i className={styles.by}>{`by `}</i>
                      <div className={styles.linkBacola}>Bacola</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divcol12}>
            <div className={styles.article}>
              <div className={styles.figureLink}>
                <img
                  className={styles.blog3370x260jpgIcon}
                  alt=""
                  src="/blog1370x260jpg@2x.png"
                />
              </div>
              <div className={styles.divpostWrapper}>
                <div className={styles.linkTips}>Grocery</div>
                <div className={styles.heading2Link}>
                  <div className={styles.butIMustContainer}>
                    <p className={styles.aDifferentKind}>
                      English Breakfast Tea With Tasty
                    </p>
                    <p className={styles.aDifferentKind}>Donut Desserts</p>
                  </div>
                </div>
                <div className={styles.diventryMeta2}>
                  <div className={styles.spanmetaItemmargin6}>
                    <div className={styles.shopNow}>2 May 2021</div>
                  </div>
                  <div className={styles.spanmetaItemmargin1}>
                    <div className={styles.shopNow}>3 comments</div>
                  </div>
                  <div className={styles.spanmetaItemmargin2}>
                    <div className={styles.spanmetaItem}>
                      <i className={styles.by}>{`by `}</i>
                      <div className={styles.linkBacola2}>Bacola</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.footer}>
        <div className={styles.divfooterSubscribe}>
          <div className={styles.divrow}>
            <div className={styles.divcol123}>
              <div className={styles.divsubscribeContent}>
                <div className={styles.heading6}>
                  $20 discount for your first order
                </div>
                <div className={styles.heading39}>
                  Join our newsletter and get...
                </div>
                <div className={styles.p}>
                  <div className={styles.joinOurEmailContainer}>
                    <p className={styles.aDifferentKind}>
                      Join our email subscription now to get updates
                    </p>
                    <p className={styles.aDifferentKind}>
                      on promotions and coupons.
                    </p>
                  </div>
                </div>
                <div className={styles.form}>
                  <div className={styles.input}>
                    <div className={styles.divplaceholder}>
                      <div className={styles.yourEmailAddress}>
                        Your email address
                      </div>
                    </div>
                  </div>
                  <div className={styles.input1}>
                    <div className={styles.subscribe}>Subscribe</div>
                  </div>
                  <div className={styles.pseudo6}>
                    <div className={styles.icon49}>
                      <img
                        className={styles.vectorIcon225}
                        alt=""
                        src="/vector101.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.divcol124}>
              <img
                className={styles.couponpngIcon}
                alt=""
                src="/couponpng@2x.png"
              />
            </div>
          </div>
        </div>
        <div className={styles.divfooterIconboxes}>
          <div className={styles.divrow1}>
            <div className={styles.divcol}>
              <div className={styles.diviconbox}>
                <div className={styles.diviconboxIcon}>
                  <div className={styles.icon50}>
                    <img
                      className={styles.vectorIcon226}
                      alt=""
                      src="/vector102.svg"
                    />
                  </div>
                </div>
                <div className={styles.heading3Link}>
                  <div className={styles.everydayFreshProducts}>
                    Everyday fresh products
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.divcol1}>
              <div className={styles.diviconbox1}>
                <div className={styles.diviconboxIcon}>
                  <div className={styles.icon51}>
                    <img
                      className={styles.vectorIcon227}
                      alt=""
                      src="/vector103.svg"
                    />
                  </div>
                </div>
                <div className={styles.heading3Link}>
                  <div className={styles.everydayFreshProducts}>
                    Free delivery for order over $70
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.divcol1}>
              <div className={styles.diviconbox2}>
                <div className={styles.diviconboxIcon}>
                  <div className={styles.icon52}>
                    <img
                      className={styles.vectorIcon228}
                      alt=""
                      src="/vector104.svg"
                    />
                  </div>
                </div>
                <div className={styles.heading3Link}>
                  <div className={styles.everydayFreshProducts}>
                    Daily Mega Discounts
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.divcol1}>
              <div className={styles.diviconbox3}>
                <div className={styles.diviconboxIcon}>
                  <div className={styles.icon53}>
                    <img
                      className={styles.vectorIcon229}
                      alt=""
                      src="/vector105.svg"
                    />
                  </div>
                </div>
                <div className={styles.heading3Link}>
                  <div className={styles.everydayFreshProducts}>
                    Best price on the market
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.divfooterWidgets}>
          <div className={styles.divcontainer}>
            <div className={styles.divrow1}>
              <div className={styles.divcol4}>
                <div className={styles.divklbfooterwidget}>
                  <div className={styles.heading42}>{`FRUIT & VEGETABLES`}</div>
                  <div className={styles.list}>
                    <div className={styles.itemLink}>Fresh Vegetables</div>
                    <div
                      className={styles.itemLink}
                    >{`Herbs & Seasonings`}</div>
                    <div className={styles.itemLink}>Fresh Fruits</div>
                    <div className={styles.itemLink}>{`Cuts & Sprouts`}</div>
                    <div
                      className={styles.itemLink}
                    >{`Exotic Fruits & Veggies`}</div>
                    <div className={styles.itemLink}>Packaged Produce</div>
                    <div className={styles.itemLink}>Party Trays</div>
                  </div>
                </div>
              </div>
              <div className={styles.divcol5}>
                <div className={styles.divklbfooterwidget}>
                  <div className={styles.heading42}>{`Breakfast & Dairy`}</div>
                  <div className={styles.list1}>
                    <div
                      className={styles.itemLink}
                    >{`Milk & Flavoured Milk`}</div>
                    <div className={styles.itemLink}>Butter and Margarine</div>
                    <div className={styles.itemLink}>Cheese</div>
                    <div className={styles.itemLink}>Eggs Substitutes</div>
                    <div className={styles.itemLink}>Honey</div>
                    <div className={styles.itemLink}>Marmalades</div>
                    <div className={styles.itemLink}>Sour Cream and Dips</div>
                    <div className={styles.itemLink}>Yogurt</div>
                  </div>
                </div>
              </div>
              <div className={styles.divcol6}>
                <div className={styles.divklbfooterwidget}>
                  <div className={styles.heading42}>{`Meat & Seafood`}</div>
                  <div className={styles.list2}>
                    <div className={styles.itemLink}>Breakfast Sausage</div>
                    <div className={styles.itemLink}>Dinner Sausage</div>
                    <div className={styles.itemLink}>Beef</div>
                    <div className={styles.itemLink}>Chicken</div>
                    <div className={styles.itemLink}>Sliced Deli Meat</div>
                    <div className={styles.itemLink}>Shrimp</div>
                    <div className={styles.itemLink}>Wild Caught Fillets</div>
                    <div className={styles.itemLink}>Crab and Shellfish</div>
                    <div className={styles.itemLink}>Farm Raised Fillets</div>
                  </div>
                </div>
              </div>
              <div className={styles.divcol6}>
                <div className={styles.divklbfooterwidget}>
                  <div className={styles.heading42}>Beverages</div>
                  <div className={styles.list3}>
                    <div className={styles.itemLink}>Water</div>
                    <div className={styles.itemLink}>Sparkling Water</div>
                    <div className={styles.itemLink}>{`Soda & Pop`}</div>
                    <div className={styles.itemLink}>Coffee</div>
                    <div
                      className={styles.itemLink}
                    >{`Milk & Plant-Based Milk`}</div>
                    <div className={styles.itemLink}>{`Tea & Kombucha`}</div>
                    <div
                      className={styles.itemLink}
                    >{`Drink Boxes & Pouches`}</div>
                    <div className={styles.itemLink}>Craft Beer</div>
                    <div className={styles.itemLink}>Wine</div>
                  </div>
                </div>
              </div>
              <div className={styles.divcol5}>
                <div className={styles.divklbfooterwidget}>
                  <div className={styles.heading42}>{`Breads & Bakery`}</div>
                  <div className={styles.list1}>
                    <div
                      className={styles.itemLink}
                    >{`Milk & Flavoured Milk`}</div>
                    <div className={styles.itemLink}>Butter and Margarine</div>
                    <div className={styles.itemLink}>Cheese</div>
                    <div className={styles.itemLink}>Eggs Substitutes</div>
                    <div className={styles.itemLink}>Honey</div>
                    <div className={styles.itemLink}>Marmalades</div>
                    <div className={styles.itemLink}>Sour Cream and Dips</div>
                    <div className={styles.itemLink}>Yogurt</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.divfooterContacts}>
          <div className={styles.divcontainer1}>
            <div className={styles.divcolumn2}>
              <div className={styles.divsitePhone}>
                <div className={styles.divphoneIcon}>
                  <div className={styles.icon54}>
                    <img
                      className={styles.vectorIcon230}
                      alt=""
                      src="/vector106.svg"
                    />
                  </div>
                </div>
                <div className={styles.divphoneDetail}>
                  <div className={styles.butIMustContainer}>8 800 555-55</div>
                  <div className={styles.span28}>
                    <div className={styles.kg}>Working 8:00 - 22:00</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.divcolumn3}>
              <div className={styles.divsiteMobileApp}>
                <div className={styles.divappContent}>
                  <div className={styles.biscuitsSnacksContainer}>
                    Download App on Mobile :
                  </div>
                  <div className={styles.discountOnYour}>
                    15% discount on your first purchase
                  </div>
                </div>
                <div className={styles.divappButtons}>
                  <div className={styles.link7}>
                    <img
                      className={styles.googlePlaypngIcon}
                      alt=""
                      src="/googleplaypng@2x.png"
                    />
                  </div>
                  <img
                    className={styles.linkAppStorepng}
                    alt=""
                    src="/link--appstorepng@2x.png"
                  />
                </div>
              </div>
              <div className={styles.list5}>
                <div className={styles.itemLink41}>
                  <div className={styles.icon55}>
                    <img
                      className={styles.vectorIcon231}
                      alt=""
                      src="/vector107.svg"
                    />
                  </div>
                </div>
                <div className={styles.itemmargin}>
                  <div className={styles.itemLink41}>
                    <div className={styles.icon56}>
                      <img
                        className={styles.vectorIcon232}
                        alt=""
                        src="/vector108.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.itemmargin}>
                  <div className={styles.itemLink41}>
                    <div className={styles.icon57}>
                      <img
                        className={styles.vectorIcon233}
                        alt=""
                        src="/vector109.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.divfooterBottom}>
          <div className={styles.divcontainer2}>
            <div className={styles.heading3Link}>
              <div className={styles.doNotMiss}>
                Copyright 2023 © Groceries Morrisons. All rights reserved.
                Powered by Saurabh Mishra.
              </div>
            </div>
            <div className={styles.navmargin}>
              <div className={styles.navList}>
                <div className={styles.itemLink44}>Privacy Policy</div>
                <div className={styles.itemLink45}>Terms and Conditions</div>
                <div className={styles.itemLink46}>Cookie</div>
              </div>
            </div>
            <div className={styles.divsitePaymentsmargin}>
              <img
                className={styles.linkPaymentsjpg}
                alt=""
                src="/link--paymentsjpg@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
      <div className={styles.aside}>
        <div className={styles.divcontainer3}>
          <div className={styles.dueToTheContainer}>
            <span>{`Due to the `}</span>
            <b>COVID 19</b>
            <span> epidemic, orders may be processed with a slight delay</span>
          </div>
        </div>
      </div>
      <div className={styles.header}>
        <div className={styles.divheaderTop}>
          <div className={styles.divcontainer4}>
            <div className={styles.navList1}>
              <div className={styles.itemLink47}>About Us</div>
              <div className={styles.itemLink48}>My account</div>
              <div className={styles.itemLink49}>Wishlist</div>
              <div className={styles.itemLink50}>Order Tracking</div>
            </div>
            <div className={styles.divcolumn4}>
              <div className={styles.divtopbarNoticemargin}>
                <div className={styles.divtopbarNotice}>
                  <div className={styles.pseudo7}>
                    <div className={styles.icon58}>
                      <img
                        className={styles.vectorIcon234}
                        alt=""
                        src="/vector110.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.secureDeliveryWithout}>
                    100% Secure delivery without contacting the courier
                  </div>
                </div>
              </div>
              <div className={styles.divtextContentmargin}>
                <div className={styles.divtextContent}>
                  <div className={styles.doNotMiss}>
                    <span>{`Need help? Call Us: `}</span>
                    <b className={styles.b}>+ 0020 500</b>
                  </div>
                </div>
              </div>
              <div className={styles.divheaderSwitchersmargin}>
                <div className={styles.divheaderSwitchers}>
                  <div className={styles.navList2}>
                    <div className={styles.itemLink51}>
                      <div className={styles.addToCart}>English</div>
                      <div className={styles.pseudo8}>
                        <div className={styles.icon59}>
                          <img
                            className={styles.vectorIcon235}
                            alt=""
                            src="/vector111.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className={styles.itemLink52}>
                      <div className={styles.addToCart}>USD</div>
                      <div className={styles.pseudo8}>
                        <div className={styles.icon59}>
                          <img
                            className={styles.vectorIcon235}
                            alt=""
                            src="/vector112.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.divheaderMain}>
          <div className={styles.divcontainer5}>
            <div className={styles.link8}>
              <img
                className={styles.bacolaLogopngIcon}
                alt=""
                src="/bacolalogopng@2x.png"
              />
              <div className={styles.spanbrandDescription}>
                <div className={styles.kg}>Online Grocery Shopping Center</div>
              </div>
            </div>
            <div className={styles.divcolumn5}>
              <div className={styles.link9}>
                <div className={styles.spanlocationDescription}>
                  <div className={styles.yourLocation}>Your Location</div>
                </div>
                <div className={styles.divcurrentLocation}>
                  <div className={styles.selectALocation}>
                    Select a Location
                  </div>
                </div>
                <div className={styles.pseudomargin}>
                  <div className={styles.icon61}>
                    <img
                      className={styles.vectorIcon237}
                      alt=""
                      src="/vector113.svg"
                    />
                  </div>
                </div>
              </div>
              <div className={styles.search}>
                <div className={styles.input2}>
                  <div className={styles.divplaceholder1}>
                    <div className={styles.yourEmailAddress}>
                      Search for products...
                    </div>
                  </div>
                </div>
                <div className={styles.button}>
                  <div className={styles.icon62}>
                    <img
                      className={styles.vectorIcon238}
                      alt=""
                      src="/vector114.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.divcolumn6}>
              <div className={styles.divheaderButtons}>
                <div className={styles.link10}>
                  <div className={styles.icon63}>
                    <img
                      className={styles.vectorIcon239}
                      alt=""
                      src="/vector115.svg"
                    />
                  </div>
                </div>
                <div className={styles.link11}>
                  <div className={styles.divcartPrice}>
                    <div className={styles.div95}>$0.00</div>
                  </div>
                  <div className={styles.divbuttonIcon}>
                    <div className={styles.icon64}>
                      <img
                        className={styles.vectorIcon240}
                        alt=""
                        src="/vector116.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.spancartCountIcon}>
                    <div className={styles.div96}>0</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.divheaderNav}>
          <div className={styles.divcontainer6}>
            <div className={styles.divallCategories}>
              <div className={styles.link12}>
                <div className={styles.iklbthIconMenuThin}>
                  <div className={styles.icon65}>
                    <img
                      className={styles.vectorIcon241}
                      alt=""
                      src="/vector117.svg"
                    />
                  </div>
                </div>
                <div className={styles.spantextmargin}>
                  <div className={styles.allCategories}>ALL CATEGORIES</div>
                </div>
                <div className={styles.divdescription}>
                  <div className={styles.total63Products}>
                    TOTAL 63 PRODUCTS
                  </div>
                </div>
                <div className={styles.pseudomargin1}>
                  <div className={styles.icon66}>
                    <img
                      className={styles.vectorIcon242}
                      alt=""
                      src="/vector118.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.nav}>
              <div className={styles.list6}>
                <div className={styles.item}>
                  <div className={styles.link13}>
                    <div className={styles.home}>Home</div>
                    <div className={styles.pseudo10}>
                      <div className={styles.icon67}>
                        <img
                          className={styles.vectorIcon243}
                          alt=""
                          src="/vector119.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles.item}>
                  <div className={styles.link14}>
                    <div className={styles.home}>Shop</div>
                    <div className={styles.pseudo10}>
                      <div className={styles.icon67}>
                        <img
                          className={styles.vectorIcon243}
                          alt=""
                          src="/vector119.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles.item}>
                  <div className={styles.link15}>
                    <div className={styles.iklbthIconMeat}>
                      <div className={styles.icon69}>
                        <img
                          className={styles.vectorIcon245}
                          alt=""
                          src="/vector120.svg"
                        />
                      </div>
                    </div>
                    <div
                      className={styles.meatsSeafood}
                    >{`Meats & Seafood`}</div>
                  </div>
                </div>
                <div className={styles.item}>
                  <div className={styles.link16}>
                    <div className={styles.iklbthIconMeat}>
                      <div className={styles.icon70}>
                        <img
                          className={styles.vectorIcon246}
                          alt=""
                          src="/vector121.svg"
                        />
                      </div>
                    </div>
                    <div className={styles.meatsSeafood}>Bakery</div>
                  </div>
                </div>
                <div className={styles.item}>
                  <div className={styles.link17}>
                    <div className={styles.iklbthIconCup}>
                      <div className={styles.icon71}>
                        <img
                          className={styles.vectorIcon247}
                          alt=""
                          src="/vector122.svg"
                        />
                      </div>
                    </div>
                    <div className={styles.meatsSeafood}>Beverages</div>
                  </div>
                </div>
                <div className={styles.item5}>
                  <div className={styles.linkBlog}>Blog</div>
                </div>
                <div className={styles.item6}>
                  <div className={styles.linkBlog}>Contact</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.divsiteCanvas}>
        <div className={styles.divsiteScroll}>
          <div className={styles.divcanvasHeader}>
            <img
              className={styles.linkBacolaLogopng}
              alt=""
              src="/link--bacolalogopng@2x.png"
            />
            <div className={styles.divcloseCanvas}>
              <div className={styles.icon72}>
                <img
                  className={styles.vectorIcon248}
                  alt=""
                  src="/vector123.svg"
                />
              </div>
              <div className={styles.icon73}>
                <img
                  className={styles.vectorIcon249}
                  alt=""
                  src="/vector124.svg"
                />
              </div>
            </div>
          </div>
          <div className={styles.divcanvasMain}>
            <div className={styles.link18}>
              <div className={styles.spanlocationDescription1}>
                <div className={styles.yourLocation}>Your Location</div>
              </div>
              <div className={styles.divcurrentLocation1}>
                <div className={styles.selectALocation1}>Select a Location</div>
              </div>
              <div className={styles.pseudomargin2}>
                <div className={styles.icon74}>
                  <img
                    className={styles.vectorIcon250}
                    alt=""
                    src="/vector125.svg"
                  />
                </div>
              </div>
            </div>
            <div className={styles.link19}>
              <div className={styles.iklbthIconMenuThin1}>
                <img
                  className={styles.vectorIcon241}
                  alt=""
                  src="/vector126.svg"
                />
                <div className={styles.icon75}>
                  <img
                    className={styles.vectorIcon252}
                    alt=""
                    src="/vector127.svg"
                  />
                </div>
              </div>
              <div className={styles.spantextmargin1}>
                <div className={styles.allCategories}>ALL CATEGORIES</div>
              </div>
              <div className={styles.pseudomargin3}>
                <div className={styles.icon76}>
                  <img
                    className={styles.vectorIcon253}
                    alt=""
                    src="/vector128.svg"
                  />
                </div>
              </div>
            </div>
            <div className={styles.heading62}>Site Navigation</div>
            <div className={styles.nav1}>
              <div className={styles.list7}>
                <div className={styles.item7}>
                  <div className={styles.link20}>
                    <div className={styles.blog}>Home</div>
                  </div>
                  <div className={styles.spanmenuDropdown}>
                    <div className={styles.icon77}>
                      <img
                        className={styles.vectorIcon254}
                        alt=""
                        src="/vector129.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link22}>
                    <div className={styles.blog}>Shop</div>
                  </div>
                  <div className={styles.spanmenuDropdown}>
                    <div className={styles.icon77}>
                      <img
                        className={styles.vectorIcon254}
                        alt=""
                        src="/vector129.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link23}>
                    <div className={styles.blog}>{`Meats & Seafood`}</div>
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link24}>
                    <div className={styles.blog}>Bakery</div>
                    <div className={styles.iklbthIconBiscuit1} />
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link25}>
                    <div className={styles.beverages1}>Beverages</div>
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link26}>
                    <div className={styles.blog}>Blog</div>
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link27}>
                    <div className={styles.blog}>Contact</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.divcanvasFooter}>
            <div className={styles.divsiteCopyright}>
              <div className={styles.copyright20231}>
                Copyright 2023 © Groceries Morrisons. All rights reserved.
                Powered by Saurabh Mishra.
              </div>
            </div>
            <div className={styles.nav2}>
              <div className={styles.list7}>
                <div className={styles.item7}>
                  <div className={styles.link28}>
                    <div className={styles.selectALocation}>English</div>
                  </div>
                  <div className={styles.spanmenuDropdown}>
                    <div className={styles.icon77}>
                      <img
                        className={styles.vectorIcon254}
                        alt=""
                        src="/vector130.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.item8}>
                  <div className={styles.link29}>
                    <div className={styles.selectALocation}>USD</div>
                  </div>
                  <div className={styles.spanmenuDropdown}>
                    <div className={styles.icon77}>
                      <img
                        className={styles.vectorIcon254}
                        alt=""
                        src="/vector130.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroceriesmorrisonscomMo;
